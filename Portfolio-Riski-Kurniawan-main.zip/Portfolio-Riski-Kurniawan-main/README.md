# Portfolio-Riski-Kurniawan
jika mengclone ijin dahulu ya
